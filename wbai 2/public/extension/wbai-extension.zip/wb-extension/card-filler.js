(function() {
  if (window.__wbCardLoaded) return;
  window.__wbCardLoaded = true;

  async function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  function setVal(el, value) {
    if (!el || !value) return false;
    el.removeAttribute('readonly');
    el.removeAttribute('disabled');
    el.focus();
    el.click();
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, String(value));
    else el.value = String(value);
    el.dispatchEvent(new Event('focus', { bubbles: true }));
    el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: String(value) }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  function norm(s) {
    return (s || '').toLowerCase().replace(/[()]/g, '').replace(/[.,]/g, '').replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();
  }

  function cleanVal(v) {
    var s = String(v).trim();
    if (/^\d[\d\s,.]*\s*(Вт|В|А\/ч|мА\*ч|об\/мин|мм|см|кг|г|шт|год|лет|ч|атм|л\/мин)$/i.test(s)) {
      return s.replace(/\s*(Вт|В|А\/ч|мА\*ч|об\/мин|мм|см|кг|г|шт|год|лет|ч|атм|л\/мин)$/i, '').trim();
    }
    return s;
  }

  function getCategory() {
    try {
      var el = document.querySelector('[class*="subject"], [class*="Subject"]');
      if (el) {
        var parts = (el.innerText || '').trim().split('/').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 2; });
        if (parts.length > 0) return parts[parts.length - 1];
        var lines = (el.innerText || '').trim().split('\n').map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 2 && s !== '/'; });
        if (lines.length > 0) return lines[lines.length - 1];
      }
    } catch(e) {}
    return '';
  }

  function parseChars(text) {
    var pairs = [];
    var lines = text.split('\n').map(function(l) { return l.trim(); }).filter(function(l) { return l.length > 0; });
    var skipHeaders = ['общие характеристики', 'питание', 'дополнительная информация', 'технические особенности', 'материалы', 'габариты', 'основные'];

    function isValue(s) {
      if (s.length > 80) return true;
      if (/шт/.test(s)) return true;
      if (s.includes('—') && s.includes(';')) return true;
      if (/^\d+([.,]\d+)?$/.test(s.trim())) return true;
      return false;
    }

    var i = 0;
    while (i < lines.length) {
      var line = lines[i];
      if (skipHeaders.indexOf(norm(line)) >= 0) { i++; continue; }
      if (line.indexOf(':') >= 0 && line.indexOf(':') < 80) {
        var idx = line.indexOf(':');
        var key = line.slice(0, idx).trim();
        var val = line.slice(idx + 1).trim();
        if (key && val && key.length < 80) { pairs.push([key, val]); i++; continue; }
      }
      if (line.length < 80 && !isValue(line) && i + 1 < lines.length) {
        var next = lines[i + 1];
        if (skipHeaders.indexOf(norm(next)) < 0) { pairs.push([line, next]); i += 2; continue; }
      }
      i++;
    }
    return pairs;
  }

  function getAllFields() {
    var fields = [];
    var seen = new Set();
    document.querySelectorAll('input:not([type="hidden"]):not([id="editable-title"]), textarea:not([id="editable-title"])').forEach(function(inp) {
      if (inp.getAttribute('data-testid') === 'card-form-main-field-title') return;
      if ((inp.id || '').includes('vendorCode')) return;
      if (seen.has(inp)) return;
      seen.add(inp);
      var wrapper = inp.closest('[class*="Field-wrapper__ChpbLLvc2p"]') || inp.closest('[class*="Field-wrapper__"][id]');
      var label = wrapper ? (wrapper.getAttribute('id') || '') : '';
      fields.push({ label: label, inputId: inp.id || '', input: inp });
    });
    return fields;
  }

  function matchField(key, fields) {
    var nk = norm(key);
    var isDim = ['длина', 'ширина', 'высота'].some(function(k) { return nk.startsWith(k); }) && !nk.includes('предмет') && !nk.includes('шнур');
    if (isDim) {
      var map = { 'длина': 'dimensions.length', 'ширина': 'dimensions.width', 'высота': 'dimensions.height' };
      for (var k in map) {
        if (nk.startsWith(k)) {
          var f = fields.find(function(f) { return (f.inputId || '').toLowerCase().includes(map[k]); });
          if (f) return f.input;
        }
      }
    }
    if (nk.includes('вес с упак') || nk.includes('вес упак')) {
      var f = fields.find(function(f) { return (f.inputId || '').toLowerCase().includes('weightbrutto'); });
      if (f) return f.input;
    }
    if (nk === 'цена' || nk.startsWith('цена ')) {
      var f = fields.find(function(f) { return (f.inputId || '').toLowerCase().includes('price') || f.label === 'price'; });
      if (f) return f.input;
    }
    for (var i = 0; i < fields.length; i++) {
      if (norm(fields[i].label) === nk) return fields[i].input;
    }
    if (nk.length >= 4) {
      for (var i = 0; i < fields.length; i++) {
        var nl = norm(fields[i].label);
        if (nl && nl.includes(nk)) return fields[i].input;
      }
      for (var i = 0; i < fields.length; i++) {
        var nl = norm(fields[i].label);
        if (nl && nl.length >= 4 && nk.includes(nl)) return fields[i].input;
      }
    }
    return null;
  }

  async function clickDropdown(value) {
    await wait(400);
    var vt = norm(value);
    var units = ['ма*ч', 'а/ч', 'вт', ' в', ' а', 'об/мин', 'мм', 'см', 'кг'];
    var allEl = Array.from(document.querySelectorAll('*')).filter(function(el) {
      if (el.children.length > 0) return false;
      var t = (el.innerText || '').trim();
      if (!t || t.length > 200) return false;
      var r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });
    for (var u = 0; u < units.length; u++) {
      for (var i = 0; i < allEl.length; i++) {
        var ot = norm(allEl[i].innerText || '');
        if (ot === vt + ' ' + units[u] || ot.startsWith(vt + ' ')) { allEl[i].click(); await wait(200); return true; }
      }
    }
    for (var i = 0; i < allEl.length; i++) {
      if (norm(allEl[i].innerText || '') === vt) { allEl[i].click(); await wait(200); return true; }
    }
    for (var i = 0; i < allEl.length; i++) {
      var ot = norm(allEl[i].innerText || '');
      if (ot && ot.length > 2 && (ot.includes(vt) || vt.includes(ot))) { allEl[i].click(); await wait(200); return true; }
    }
    return false;
  }

  function getTemplates() {
    try { return JSON.parse(localStorage.getItem('wb_templates') || '{}'); } catch(e) { return {}; }
  }
  function saveTemplate(name, data) {
    try {
      var t = getTemplates();
      t[name] = Object.assign({}, data, { date: new Date().toLocaleDateString('ru') });
      localStorage.setItem('wb_templates', JSON.stringify(t));
    } catch(e) {}
  }
  function delTemplate(name) {
    try { var t = getTemplates(); delete t[name]; localStorage.setItem('wb_templates', JSON.stringify(t)); } catch(e) {}
  }

  function showToast(msg, ok) {
    var t = document.getElementById('wb-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'wb-toast';
      t.style.cssText = 'position:fixed;bottom:90px;left:50%;transform:translateX(-50%);padding:12px 20px;border-radius:10px;font-size:13px;font-weight:600;z-index:999999;font-family:-apple-system,sans-serif;box-shadow:0 4px 20px rgba(0,0,0,0.15);max-width:500px;text-align:center;transition:opacity 0.3s;';
      document.body.appendChild(t);
    }
    t.style.background = ok ? '#1a2d1a' : '#2a1a1a';
    t.style.border = ok ? '1px solid #4caf50' : '1px solid #c0392b';
    t.style.color = ok ? '#7ed47e' : '#ff8888';
    t.textContent = msg;
    t.style.opacity = '1';
    clearTimeout(t._tm);
    if (!msg.includes('\u2699\ufe0f')) t._tm = setTimeout(function() { t.style.opacity = '0'; }, 7000);
  }

  function showSaveDialog(data) {
    return new Promise(function(resolve) {
      var ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:1000001;display:flex;align-items:center;justify-content:center;';
      var m = document.createElement('div');
      m.style.cssText = 'background:#fff;border-radius:14px;padding:20px;width:380px;font-family:-apple-system,sans-serif;box-shadow:0 10px 40px rgba(0,0,0,0.2);';
      m.innerHTML = '<div style="font-size:15px;font-weight:700;color:#1a1a1a;margin-bottom:8px;">\uD83D\uDCBE \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u0448\u0430\u0431\u043b\u043e\u043d?</div>' +
        '<div style="font-size:12px;color:#888;margin-bottom:14px;">\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 \u0440\u0430\u0437 \u043c\u043e\u0436\u043d\u043e \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u0438\u0437 \u0441\u043f\u0438\u0441\u043a\u0430</div>' +
        '<input id="wb-sname" type="text" placeholder="\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0448\u0430\u0431\u043b\u043e\u043d\u0430" style="width:100%;box-sizing:border-box;border:1px solid #e0d4f7;border-radius:8px;padding:9px 12px;font-size:13px;font-family:inherit;outline:none;color:#333;margin-bottom:12px;">' +
        '<div style="display:flex;gap:8px;">' +
        '<button id="wb-sno" style="flex:1;padding:9px;border:1px solid #ddd;border-radius:8px;background:#f5f5f5;color:#555;font-size:13px;font-weight:600;cursor:pointer;">\u041d\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0442\u044c</button>' +
        '<button id="wb-syes" style="flex:1.5;padding:9px;border:none;border-radius:8px;background:linear-gradient(135deg,#7b2ff7,#5a1fc7);color:#fff;font-size:13px;font-weight:700;cursor:pointer;">\uD83D\uDCBE \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c</button>' +
        '</div>';
      ov.appendChild(m);
      document.body.appendChild(ov);
      document.getElementById('wb-sno').onclick = function() { ov.remove(); resolve(null); };
      document.getElementById('wb-syes').onclick = function() {
        var name = document.getElementById('wb-sname').value.trim();
        if (!name) { document.getElementById('wb-sname').style.borderColor = '#ff4444'; return; }
        saveTemplate(name, data);
        ov.remove();
        resolve(name);
      };
    });
  }

  function showModal(productName) {
    return new Promise(function(resolve) {
      var templates = getTemplates();
      var cat = getCategory();
      var tNames = Object.keys(templates).filter(function(n) {
        var t = templates[n];
        if (!t.category || !cat) return true;
        return t.category.toLowerCase() === cat.toLowerCase();
      });

      var ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:1000000;display:flex;align-items:center;justify-content:center;';
      var m = document.createElement('div');
      m.style.cssText = 'background:#fff;border-radius:16px;padding:24px;width:560px;max-width:95vw;font-family:-apple-system,sans-serif;box-shadow:0 20px 60px rgba(0,0,0,0.3);max-height:90vh;overflow-y:auto;';

      var tmplHtml = '';
      if (tNames.length > 0) {
        var btns = tNames.map(function(n) {
          var t = templates[n];
          return '<div style="display:inline-flex;align-items:center;gap:3px;margin:3px;">' +
            '<button class="wb-tl" data-n="' + n + '" style="padding:4px 10px;border:1px solid #b3d4ff;border-radius:20px;background:#e8f0ff;color:#1a56db;font-size:11px;font-weight:600;cursor:pointer;">' + n + (t.date ? ' (' + t.date + ')' : '') + '</button>' +
            '<button class="wb-td" data-n="' + n + '" style="padding:2px 5px;border:none;background:none;color:#aaa;font-size:11px;cursor:pointer;">\u2715</button>' +
            '</div>';
        }).join('');
        tmplHtml = '<div style="background:#f0f7ff;border:1px solid #b3d4ff;border-radius:8px;padding:10px 14px;margin-bottom:12px;">' +
          '<div style="font-size:12px;font-weight:600;color:#1a56db;margin-bottom:6px;">\uD83D\uDCBE \u0428\u0430\u0431\u043b\u043e\u043d\u044b' + (cat ? ' \u2014 ' + cat : '') + ':</div>' +
          '<div>' + btns + '</div></div>';
      }

      m.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">' +
          '<div><div style="font-size:16px;font-weight:700;color:#1a1a1a;">\u2728 AI \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u0435 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438</div>' +
          '<div style="font-size:12px;color:#888;margin-top:2px;">\u0422\u043e\u0432\u0430\u0440: <b>' + productName + '</b>' + (cat ? ' \u00b7 ' + cat : '') + '</div></div>' +
          '<button id="wb-cls" style="background:none;border:none;font-size:22px;cursor:pointer;color:#888;line-height:1;">\u00d7</button>' +
        '</div>' +
        tmplHtml +
        '<div style="margin-bottom:12px;">' +
          '<label style="font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:6px;">\u0425\u0410\u0420\u0410\u041a\u0422\u0415\u0420\u0418\u0421\u0422\u0418\u041a\u0418 <span style="color:#888;font-weight:400">(\u043b\u044e\u0431\u043e\u0439 \u0444\u043e\u0440\u043c\u0430\u0442)</span></label>' +
          '<textarea id="wb-chars" rows="8" placeholder="\u0412\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u0441 \u0441\u0430\u0439\u0442\u0430 WB \u0438\u043b\u0438 \u0432\u0432\u0435\u0434\u0438\u0442\u0435:\n\n\u041c\u043e\u0449\u043d\u043e\u0441\u0442\u044c (\u0412\u0442): 1600\n\u0422\u0438\u043f \u0430\u043a\u043a\u0443\u043c\u0443\u043b\u044f\u0442\u043e\u0440\u0430: Li-Ion\n\u0421\u0442\u0440\u0430\u043d\u0430 \u043f\u0440\u043e\u0438\u0437\u0432\u043e\u0434\u0441\u0442\u0432\u0430: \u041a\u0438\u0442\u0430\u0439" style="width:100%;box-sizing:border-box;border:1px solid #e0d4f7;border-radius:8px;padding:10px;font-size:12px;font-family:-apple-system,sans-serif;resize:vertical;line-height:1.6;outline:none;color:#333;"></textarea>' +
        '</div>' +
        '<div style="background:#fff8e1;border:1px solid #ffe082;border-radius:8px;padding:10px 14px;margin-bottom:12px;">' +
          '<div style="font-size:12px;font-weight:600;color:#f57f17;margin-bottom:8px;">\u26a0\ufe0f \u041e\u0411\u042f\u0417\u0410\u0422\u0415\u041b\u042c\u041d\u041e</div>' +
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">' +
            '<div><label style="font-size:11px;color:#555;display:block;margin-bottom:3px;">\u0414\u043b\u0438\u043d\u0430 \u0443\u043f\u0430\u043a\u043e\u0432\u043a\u0438 (\u0441\u043c)</label><input id="wb-len" type="number" placeholder="31" style="width:100%;box-sizing:border-box;border:1px solid #ffe082;border-radius:6px;padding:6px 8px;font-size:13px;outline:none;"></div>' +
            '<div><label style="font-size:11px;color:#555;display:block;margin-bottom:3px;">\u0428\u0438\u0440\u0438\u043d\u0430 \u0443\u043f\u0430\u043a\u043e\u0432\u043a\u0438 (\u0441\u043c)</label><input id="wb-wid" type="number" placeholder="27" style="width:100%;box-sizing:border-box;border:1px solid #ffe082;border-radius:6px;padding:6px 8px;font-size:13px;outline:none;"></div>' +
            '<div><label style="font-size:11px;color:#555;display:block;margin-bottom:3px;">\u0412\u044b\u0441\u043e\u0442\u0430 \u0443\u043f\u0430\u043a\u043e\u0432\u043a\u0438 (\u0441\u043c)</label><input id="wb-hei" type="number" placeholder="10" style="width:100%;box-sizing:border-box;border:1px solid #ffe082;border-radius:6px;padding:6px 8px;font-size:13px;outline:none;"></div>' +
            '<div><label style="font-size:11px;color:#555;display:block;margin-bottom:3px;">\u0412\u0435\u0441 \u0441 \u0443\u043f\u0430\u043a\u043e\u0432\u043a\u043e\u0439 (\u043a\u0433)</label><input id="wb-wei" type="number" step="0.1" placeholder="2.1" style="width:100%;box-sizing:border-box;border:1px solid #ffe082;border-radius:6px;padding:6px 8px;font-size:13px;outline:none;"></div>' +
            '<div style="grid-column:1/-1;"><label style="font-size:11px;color:#555;display:block;margin-bottom:3px;">\u0426\u0435\u043d\u0430 (\u20bd)</label><input id="wb-pri" type="number" placeholder="3900" style="width:100%;box-sizing:border-box;border:1px solid #ffe082;border-radius:6px;padding:6px 8px;font-size:13px;outline:none;"></div>' +
          '</div>' +
        '</div>' +
        '<div style="margin-bottom:14px;">' +
          '<label style="font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:4px;">\u041a\u041b\u042e\u0427\u0415\u0412\u042b\u0415 \u0421\u041b\u041e\u0412\u0410 (\u043d\u0435\u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u043e)</label>' +
          '<input id="wb-kw" type="text" placeholder="\u0418\u0437 Sellego \u0438\u043b\u0438 \u043e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u043f\u0443\u0441\u0442\u044b\u043c" style="width:100%;box-sizing:border-box;border:1px solid #e0d4f7;border-radius:8px;padding:9px 12px;font-size:13px;font-family:inherit;outline:none;color:#333;">' +
        '</div>' +
        '<div id="wb-err" style="display:none;background:#fff0f0;border:1px solid #ffcccc;border-radius:8px;padding:8px 12px;color:#cc0000;font-size:12px;margin-bottom:10px;"></div>' +
        '<div style="display:flex;gap:10px;">' +
          '<button id="wb-cancel" style="flex:1;padding:10px;border:1px solid #ddd;border-radius:8px;background:#f5f5f5;color:#555;font-size:14px;font-weight:600;cursor:pointer;">\u041e\u0442\u043c\u0435\u043d\u0430</button>' +
          '<button id="wb-ok" style="flex:2;padding:10px;border:none;border-radius:8px;background:linear-gradient(135deg,#7b2ff7,#5a1fc7);color:#fff;font-size:14px;font-weight:700;cursor:pointer;">\uD83D\uDE80 \u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u044c \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0443</button>' +
        '</div>';

      ov.appendChild(m);
      document.body.appendChild(ov);

      var fromTmpl = false;

      m.querySelectorAll('.wb-tl').forEach(function(btn) {
        btn.onclick = function() {
          var n = btn.getAttribute('data-n');
          var t = templates[n];
          if (!t) return;
          var charsEl = document.getElementById('wb-chars');
          var lenEl = document.getElementById('wb-len');
          var widEl = document.getElementById('wb-wid');
          var heiEl = document.getElementById('wb-hei');
          var weiEl = document.getElementById('wb-wei');
          var priEl = document.getElementById('wb-pri');
          var kwEl = document.getElementById('wb-kw');
          if (charsEl && t.chars) charsEl.value = t.chars;
          if (lenEl && t.length) lenEl.value = t.length;
          if (widEl && t.width) widEl.value = t.width;
          if (heiEl && t.height) heiEl.value = t.height;
          if (weiEl && t.weight) weiEl.value = t.weight;
          if (priEl && t.price) priEl.value = t.price;
          if (kwEl && t.kw) kwEl.value = t.kw;
          m.querySelectorAll('.wb-tl').forEach(function(b) { b.style.background = '#e8f0ff'; });
          btn.style.background = '#b3d4ff';
          fromTmpl = true;
        };
      });

      m.querySelectorAll('.wb-td').forEach(function(btn) {
        btn.onclick = function() {
          var n = btn.getAttribute('data-n');
          if (confirm('Удалить шаблон "' + n + '"?')) { delTemplate(n); btn.closest('div').remove(); }
        };
      });

      document.getElementById('wb-cls').onclick = function() { ov.remove(); resolve(null); };
      document.getElementById('wb-cancel').onclick = function() { ov.remove(); resolve(null); };
      document.getElementById('wb-ok').onclick = function() {
        var lenEl = document.getElementById('wb-len');
        var widEl = document.getElementById('wb-wid');
        var heiEl = document.getElementById('wb-hei');
        var weiEl = document.getElementById('wb-wei');
        var priEl = document.getElementById('wb-pri');
        var charsEl = document.getElementById('wb-chars');
        var kwEl = document.getElementById('wb-kw');
        var len = lenEl ? lenEl.value.trim() : '';
        var wid = widEl ? widEl.value.trim() : '';
        var hei = heiEl ? heiEl.value.trim() : '';
        var wei = weiEl ? weiEl.value.trim() : '';
        var pri = priEl ? priEl.value.trim() : '';
        if (!len || !wid || !hei || !wei || !pri) {
          var e = document.getElementById('wb-err');
          if (e) { e.textContent = 'Заполните габариты, вес и цену!'; e.style.display = 'block'; }
          return;
        }
        var chars = charsEl ? charsEl.value.trim() : '';
        var kw = kwEl ? kwEl.value.trim() : '';
        ov.remove();
        resolve({ chars: chars, kw: kw, length: len, width: wid, height: hei, weight: wei, price: pri, fromTemplate: fromTmpl });
      };
    });
  }

  async function callClaude(prompt) {
    return new Promise(function(resolve) {
      chrome.runtime.sendMessage({ action: 'callAI', prompt: prompt }, function(resp) {
        resolve(resp && resp.text ? resp.text : null);
      });
    });
  }

  // Читаем заполненные поля через innerText
  function readFilledFields() {
    var pairs = [];
    var data = { length: '', width: '', height: '', weight: '', price: '' };

    // Поля которые пропускаем
    var skipIds = ['subjectInfo.supplierSubject', 'brand', 'description', 'editable-description', 'skus', 'swatch', 'photo', 'upload-by-link'];

    document.querySelectorAll('[class*="Field-wrapper__ChpbLLvc2p"][id]').forEach(function(wrapper) {
      var id = wrapper.id;
      if (!id) return;
      if (skipIds.indexOf(id) >= 0) return;

      if (id === 'length' || id === 'width' || id === 'height' || id === 'weightBrutto' || id === 'price') {
        var inp = wrapper.querySelector('input');
        if (inp && inp.value) {
          if (id === 'length') data.length = inp.value;
          if (id === 'width') data.width = inp.value;
          if (id === 'height') data.height = inp.value;
          if (id === 'weightBrutto') data.weight = inp.value;
          if (id === 'price') data.price = inp.value;
        }
        return;
      }

      // Читаем через input value напрямую
      var inp2 = wrapper.querySelector('input:not([type="hidden"])');
      if (inp2 && inp2.value && inp2.value.trim()) {
        var val = inp2.value.trim();
        // Пропускаем поля с placeholder текстом
        if (val === 'Выбрать' || val === 'Укажите' || val.startsWith('Укажите цвет')) return;
        pairs.push(id + ': ' + val);
        return;
      }

      // Читаем chips через innerText только значимые строки
      var text = (wrapper.innerText || '').trim();
      var lines = text.split('\n').map(function(l) { return l.trim(); }).filter(function(l) { return l.length > 0; });
      if (lines.length >= 2) {
        // Убираем первую строку (название поля) и мусорные строки
        var vals = lines.slice(1).filter(function(l) {
          if (l === 'x' || l === '+' || l === 'Выбрать') return false;
          if (/^\d+\s*\/\s*\d+$/.test(l)) return false;
          if (l.includes('Доступно') || l.includes('Сгенерировать')) return false;
          if (l.includes('поставьте галочку') || l.includes('воспользуйтесь')) return false;
          if (l.includes('Изменить') || l.includes('18+')) return false;
          if (l.length > 150) return false;
          return true;
        });
        if (vals.length > 0 && vals[0] !== lines[0]) {
          pairs.push(id + ': ' + vals.join('; '));
        }
      }
    });
    data.chars = pairs.join('\n');
    return data;
  }

  async function fillCard() {
    var nameEl = document.getElementById('editable-title');
    var productName = nameEl ? (nameEl.value || nameEl.innerText || '') : '';
    productName = productName.trim() || 'товар';

    var showBtn = Array.from(document.querySelectorAll('button')).find(function(b) {
      return (b.innerText || '').trim().includes('Показать все');
    });
    if (showBtn) { showBtn.click(); await wait(800); }

    var userInput = await showModal(productName);
    if (!userInput) return;

    var fields = getAllFields();
    var filled = 0;

    showToast('Заполняю характеристики...', true);

    if (userInput.chars) {
      var pairs = parseChars(userInput.chars);
      for (var i = 0; i < pairs.length; i++) {
        var key = pairs[i][0];
        var raw = pairs[i][1];
        var val = cleanVal(raw);
        var inp = matchField(key, fields);
        if (!inp) continue;
        setVal(inp, val);
        filled++;
        var nk = norm(key);
        var isDim = ['длина', 'ширина', 'высота'].some(function(k) { return nk.startsWith(k); }) && !nk.includes('предмет') && !nk.includes('шнур');
        var isKomplekt = nk.includes('комплект');
        var noDropdown = isDim || nk.includes('вес с упак') || nk === 'цена' || nk.includes('модель') || nk.includes('артикул');

        if (isKomplekt) {
          await wait(800);
          var tnvedOpts = document.querySelectorAll('[class*="Tnved-option-component__label"]');
          if (tnvedOpts.length > 0) { tnvedOpts[0].click(); await wait(300); }
        } else if (!noDropdown) {
          await wait(val.length > 30 ? 1200 : 600);
          await clickDropdown(val);
        } else {
          inp.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab', keyCode: 9 }));
        }
        await wait(250);
      }
    }

    var dimMap = [
      ['dimensions.length', userInput.length],
      ['dimensions.width', userInput.width],
      ['dimensions.height', userInput.height],
      ['dimensions.weightbrutto', userInput.weight]
    ];
    for (var i = 0; i < dimMap.length; i++) {
      var f = fields.find(function(f) { return (f.inputId || '').toLowerCase().includes(dimMap[i][0]); });
      if (f) { setVal(f.input, dimMap[i][1]); filled++; await wait(150); }
    }
    var pf = fields.find(function(f) { return (f.inputId || '').toLowerCase().includes('price') || f.label === 'price'; });
    if (pf) { setVal(pf.input, userInput.price); filled++; await wait(150); }

    showToast('Генерирую описание...', true);
    var kwText = userInput.kw
      ? 'ОБЯЗАТЕЛЬНО включи все эти ключевые слова в текст: ' + userInput.kw
      : 'Подбери топ поисковые запросы покупателей на WB для "' + productName + '".';

    var desc = await callClaude(
      'Ты SEO-копирайтер для Wildberries. Напиши описание товара которое поднимет карточку в поиске WB и увеличит конверсию.\n\n' +
      'ТОВАР: ' + productName + '\n' +
      'ХАРАКТЕРИСТИКИ (уже заполнены отдельно — НЕ повторяй их): ' + (userInput.chars || '') + '\n\n' +
      kwText + '\n\n' +
      'СТРУКТУРА ОПИСАНИЯ:\n' +
      '1. Сильное первое предложение с главным ключевым запросом\n' +
      '2. Преимущества товара для покупателя\n' +
      '3. Сценарии использования — где и как применяется\n' +
      '4. Кому подходит\n' +
      '5. Дополнительные SEO-ключи в естественном виде\n' +
      '6. Завершение с мотивацией к покупке\n\n' +
      'ПРАВИЛА:\n' +
      '- До 1900 символов\n' +
      '- НЕ повторяй характеристики которые уже в карточке (размеры, вес, мощность, материал и т.д.)\n' +
      '- Используй высокочастотные запросы WB органично в разных словоформах\n' +
      '- Добавь синонимы, связанные запросы, разговорные формулировки покупателей\n' +
      '- Текст должен читаться естественно — никакого спама ключами\n' +
      '- НЕ начинай с # или заголовков\n' +
      '- Пиши абзацами без маркеров и списков\n' +
      '- Без хэштегов\n' +
      '- Акцент на поисковые алгоритмы Wildberries, не Google\n' +
      'Только текст описания.'
    );

    var descEl = Array.from(document.querySelectorAll('textarea')).find(function(t) {
      return t.id !== 'editable-title' && t.getAttribute('data-testid') !== 'card-form-main-field-title';
    });
    if (descEl && desc) {
      var cleanDesc = desc.trim().replace(/^#+\s*/gm, '').replace(/\*\*/g, '').trim();
      setVal(descEl, cleanDesc);
      filled++;
      await wait(300);
    }

    var barcodeBtn = Array.from(document.querySelectorAll('button')).find(function(b) {
      return (b.innerText || '').toLowerCase().includes('баркод');
    });
    if (barcodeBtn) { barcodeBtn.click(); filled++; await wait(500); }

    showToast('Готово! Заполнено ' + filled + ' полей.', true);

    if (!userInput.fromTemplate) {
      await wait(800);
      var name = await showSaveDialog({
        chars: userInput.chars, length: userInput.length, width: userInput.width,
        height: userInput.height, weight: userInput.weight, price: userInput.price,
        kw: userInput.kw, category: getCategory()
      });
      if (name) showToast('Шаблон "' + name + '" сохранён!', true);
    }
  }

  // Автосохранение при ручном заполнении
  function watchCreateBtn() {
    var btn = Array.from(document.querySelectorAll('button')).find(function(b) {
      return (b.innerText || '').includes('Создать и завершить');
    });
    if (!btn || btn.__wbWatched) return;
    btn.__wbWatched = true;
    btn.addEventListener('click', function() {
      setTimeout(function() {
        var data = readFilledFields();
        if (!data.chars && !data.price) return;
        data.category = getCategory();
        showSaveDialog(data).then(function(name) {
          if (name) showToast('Шаблон "' + name + '" сохранён!', true);
        });
      }, 300);
    }, { once: true });
  }

  function injectBtn() {
    if (document.getElementById('wb-card-btn')) return;
    var createBtn = Array.from(document.querySelectorAll('button')).find(function(b) {
      return (b.innerText || '').includes('Создать и завершить') || (b.innerText || '').includes('Сохранить');
    });
    if (!createBtn) return;
    var btn = document.createElement('button');
    btn.id = 'wb-card-btn';
    btn.type = 'button';
    btn.textContent = 'AI заполнить';
    btn.style.cssText = 'background:linear-gradient(135deg,#7b2ff7,#5a1fc7);color:#fff;border:none;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit;margin-right:12px;white-space:nowrap;';
    btn.onclick = fillCard;
    createBtn.parentElement.insertBefore(btn, createBtn);
    watchCreateBtn();
  }

  var obs = new MutationObserver(function() {
    var has = Array.from(document.querySelectorAll('button')).some(function(b) {
      return (b.innerText || '').includes('Создать и завершить') || (b.innerText || '').includes('Сохранить');
    });
    if (has) setTimeout(injectBtn, 400);
    else { var b = document.getElementById('wb-card-btn'); if (b) b.remove(); }
  });
  obs.observe(document.body, { childList: true, subtree: true });
  setTimeout(injectBtn, 1000);
})();

// ===== ГЕНЕРАЦИЯ НАЗВАНИЯ =====
(function() {
  var titleBtnInjected = false;

  async function generateTitle() {
    var nameEl = document.getElementById('editable-title');
    if (!nameEl) { alert('Поле названия не найдено'); return; }

    var currentName = (nameEl.value || nameEl.innerText || '').trim();
    var cat = (document.querySelector('[class*="subject"], [class*="Subject"]') || {}).innerText || '';
    cat = cat.split('/').pop().trim();

    var btn = document.getElementById('wb-title-btn');
    if (btn) { btn.textContent = '⏳'; btn.disabled = true; }

    var prompt =
      'Придумай SEO-название товара для Wildberries.\n\n' +
      'ТОВАР: ' + (currentName || cat || 'товар') + '\n' +
      'КАТЕГОРИЯ: ' + cat + '\n\n' +
      'ПРАВИЛА:\n' +
      '- Максимум 60 символов\n' +
      '- Начни с главного высокочастотного запроса WB\n' +
      '- Добавь 2-3 важных характеристики или ключевых слова\n' +
      '- Без лишних слов и воды\n' +
      '- Пример: "Шуруповерт аккумуляторный для дома мощный 48В"\n' +
      'Напиши только название без кавычек и пояснений.';

    chrome.runtime.sendMessage({ action: 'callAI', prompt: prompt }, function(resp) {
      if (btn) { btn.textContent = '✨'; btn.disabled = false; }
      if (!resp || !resp.text) { alert('Ошибка AI'); return; }

      var title = resp.text.trim().replace(/^["«»]+|["«»]+$/g, '').trim();
      if (title.length > 60) title = title.slice(0, 60).trim();

      // Вставляем в поле названия
      nameEl.focus();
      nameEl.click();
      var proto = HTMLTextAreaElement.prototype;
      var desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(nameEl, title);
      else nameEl.value = title;
      nameEl.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: title }));
      nameEl.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  function injectTitleBtn() {
    if (document.getElementById('wb-title-btn')) return;
    var nameEl = document.getElementById('editable-title');
    if (!nameEl) return;

    var btn = document.createElement('button');
    btn.id = 'wb-title-btn';
    btn.type = 'button';
    btn.textContent = '✨';
    btn.title = 'AI сгенерирует SEO-название';
    btn.style.cssText = 'position:absolute;right:8px;top:50%;transform:translateY(-50%);background:linear-gradient(135deg,#7b2ff7,#5a1fc7);color:#fff;border:none;border-radius:6px;width:28px;height:28px;font-size:14px;cursor:pointer;z-index:100;display:flex;align-items:center;justify-content:center;';
    btn.onclick = generateTitle;

    var parent = nameEl.parentElement;
    if (parent) {
      parent.style.position = 'relative';
      parent.appendChild(btn);
    }
    titleBtnInjected = true;
  }

  var titleObs = new MutationObserver(function() {
    if (document.getElementById('editable-title') && !document.getElementById('wb-title-btn')) {
      setTimeout(injectTitleBtn, 500);
    }
  });
  titleObs.observe(document.body, { childList: true, subtree: true });
  setTimeout(injectTitleBtn, 1500);
})();
