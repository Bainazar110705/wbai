// popup.js

let selType = 'positive';
let reviewText = '';
let selIdx = -1;
let variants = [];

// Тип отзыва
document.getElementById('typeRow').querySelectorAll('.tb').forEach(btn => {
  btn.addEventListener('click', () => {
    selType = btn.dataset.type;
    document.querySelectorAll('.tb').forEach(b => b.classList.toggle('on', b.dataset.type === selType));
  });
});

// Сканировать страницу
document.getElementById('scanBtn').addEventListener('click', () => {
  const btn = document.getElementById('scanBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Читаем...';
  hideErr();

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs[0];
    if (!tab || !tab.url || !tab.url.includes('seller.wildberries.ru')) {
      showErr('Откройте seller.wildberries.ru и нажмите на отзыв в списке');
      btn.disabled = false; btn.textContent = '🔍 Прочитать отзыв со страницы';
      return;
    }

    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }, () => {
      chrome.tabs.sendMessage(tab.id, { action: 'getReview' }, resp => {
        btn.disabled = false; btn.textContent = '🔍 Прочитать отзыв со страницы';

        if (chrome.runtime.lastError || !resp) {
          showErr('Не удалось прочитать. Убедитесь что открыта боковая панель с отзывом и попробуйте снова.');
          return;
        }

        if (resp.review) {
          setReview(resp.review);

          if (resp.product) {
            document.getElementById('rProduct').textContent = resp.product;
            // Автозаполнение ниши из названия товара
            const nicheInput = document.getElementById('nicheInput');
            if (!nicheInput.value) { const w = resp.product.split(' ').slice(0,3).join(' '); nicheInput.value = w; chrome.storage.local.set({ niche: w }); }
          }

          if (resp.rating) {
            const map = { 5: 'positive', 4: 'neutral', 3: 'neutral', 2: 'negative', 1: 'negative' };
            selType = map[resp.rating] || 'positive';
            document.querySelectorAll('.tb').forEach(b => b.classList.toggle('on', b.dataset.type === selType));
          }

          hideErr();
        } else {
          showErr('Отзыв не найден. Нажмите на отзыв чтобы открылась боковая панель, затем попробуйте снова. Или вставьте текст вручную.');
        }
      });
    });
  });
});

// Вручную
document.getElementById('manualLink').addEventListener('click', () => {
  const w = document.getElementById('manualWrap');
  w.style.display = w.style.display === 'block' ? 'none' : 'block';
});

document.getElementById('useBtn').addEventListener('click', () => {
  const txt = document.getElementById('manualTxt').value.trim();
  if (!txt) return;
  setReview(txt);
  document.getElementById('manualWrap').style.display = 'none';
  hideErr();
});

function setReview(text) {
  reviewText = text;
  const el = document.getElementById('rBody');
  el.textContent = text;
  el.classList.remove('empty');
}

// Сохраняем нишу
document.getElementById('nicheInput').addEventListener('change', () => {
  chrome.storage.local.set({ niche: document.getElementById('nicheInput').value });
});

// Генерация
document.getElementById('genBtn').addEventListener('click', generate);

async function generate() {
  if (!reviewText) { showErr('Сначала прочитайте или вставьте отзыв'); return; }

  const niche = document.getElementById('nicheInput').value.trim() || 'товар';
  hideErr();
  document.getElementById('genBtn').disabled = true;
  document.getElementById('loading').style.display = 'block';
  document.getElementById('results').style.display = 'none';
  document.getElementById('okMsg').style.display = 'none';
  selIdx = -1;

  const typeLabel = {
    positive: '5 звёзд — хвалит',
    negative: '1-2 звезды — злой',
    neutral: '3-4 звезды — нейтральный',
    weird: 'странный или необычный'
  };

  const stored = await new Promise(r => chrome.storage.local.get(['examples', 'rules'], r));
  const exs = (stored.examples || []).filter(e => e.type === selType).slice(-3);
  const exBlock = exs.length ? '\n\nМои примеры ответов:\n' + exs.map(e => `Отзыв: "${e.review}"\nОтвет: "${e.answer}"`).join('\n\n') : '';
  const rulesBlock = stored.rules ? '\nДополнительные правила: ' + stored.rules : '';

  const prompt = `ЗАДАЧА: Ты — дерзкий мемный SMM менеджер магазина на Wildberries. Напиши 3 варианта ответа на отзыв покупателя.

ГЛАВНОЕ ПРАВИЛО: юмор ТОЧНО ПО ТЕМЕ отзыва — цепляйся за конкретные слова и детали которые написал покупатель. Шутка должна быть понятна всем кто прочитает. Никакого общего юмора — только про то что написано в отзыве.

СТИЛЬ: дерзкий, мемный, уважительный к покупателю, 2-4 предложения максимум, никаких "Спасибо за ваш отзыв!", используй метафоры и шутки связанные с товаром.

ТОВАР/НИША: ${niche}${rulesBlock}${exBlock}

ТИП ОТЗЫВА: ${typeLabel[selType]}
ОТЗЫВ: "${reviewText}"

Напиши ровно 3 варианта. Каждый с новой строки:
1. [текст первого варианта]
2. [текст второго варианта]
3. [текст третьего варианта]

Только тексты вариантов, никаких пояснений и заголовков.`;

  chrome.runtime.sendMessage({ action: 'callAI', prompt }, resp => {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('genBtn').disabled = false;

    if (chrome.runtime.lastError || !resp) {
      showErr('Ошибка соединения. Перезагрузите расширение.');
      return;
    }
    if (resp.error) { showErr('Ошибка AI: ' + resp.error); return; }

    const lines = resp.text.split('\n').map(l => l.trim()).filter(l => /^[123][\.\)]/.test(l));
    variants = lines.length ? lines.map(l => l.replace(/^[123][\.\)]\s*/, '')) : [resp.text.trim()];
    renderVariants();
  });
}

function renderVariants() {
  const list = document.getElementById('varList');
  list.innerHTML = variants.map((v, i) =>
    `<div class="vc" data-i="${i}"><div class="vn">ВАРИАНТ ${i + 1}</div><div class="vt">${v}</div></div>`
  ).join('');
  list.querySelectorAll('.vc').forEach(el => {
    el.addEventListener('click', () => {
      selIdx = parseInt(el.dataset.i);
      list.querySelectorAll('.vc').forEach(c => c.classList.toggle('on', c.dataset.i == selIdx));
      document.getElementById('insBtn').disabled = false;
      document.getElementById('cpBtn').disabled = false;
      document.getElementById('okMsg').style.display = 'none';
    });
  });
  document.getElementById('results').style.display = 'block';
  document.getElementById('insBtn').disabled = true;
  document.getElementById('cpBtn').disabled = true;
}

// Вставить в WB
document.getElementById('insBtn').addEventListener('click', () => {
  if (selIdx < 0) return;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'insertAnswer', text: variants[selIdx] }, resp => {
      const msg = document.getElementById('okMsg');
      if (resp && resp.ok) {
        msg.style.cssText = 'background:#1a2d1a;border:1px solid #4caf50;color:#7ed47e;display:block';
        msg.textContent = '✅ Вставлено! Нажмите отправить на WB →';
      } else {
        msg.style.cssText = 'background:#2a1e00;border:1px solid #aa6600;color:#ffaa44;display:block';
        msg.textContent = '⚠️ Не вставилось — нажмите Скопировать и вставьте вручную (Ctrl+V)';
      }
    });
  });
});

// Скопировать
document.getElementById('cpBtn').addEventListener('click', () => {
  if (selIdx < 0) return;
  navigator.clipboard.writeText(variants[selIdx]).then(() => {
    const btn = document.getElementById('cpBtn');
    const orig = btn.textContent;
    btn.textContent = '✅ Скопировано!';
    setTimeout(() => btn.textContent = orig, 2000);
  });
});

function showErr(msg) { const e = document.getElementById('errBox'); e.textContent = msg; e.style.display = 'block'; }
function hideErr() { document.getElementById('errBox').style.display = 'none'; }

// Загрузить сохранённую нишу
chrome.storage.local.get(['niche'], d => {
  if (d.niche) document.getElementById('nicheInput').value = d.niche;
});
