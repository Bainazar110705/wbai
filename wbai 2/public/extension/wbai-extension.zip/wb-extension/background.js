// background.js — Anthropic Claude API

const API_KEY = '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';
const API_URL = 'https://api.anthropic.com/v1/messages';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'callAI') {
    callClaude(request.prompt).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
});

async function callClaude(prompt) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_KEY,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 800,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error('Ошибка ' + response.status + ': ' + err.slice(0, 200));
  }

  const data = await response.json();
  const text = data?.content?.[0]?.text;
  if (!text) throw new Error('Пустой ответ');
  return { text };
}

// Инжектируем скрипты при каждой навигации на WB
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('seller.wildberries.ru')) {
    chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js', 'card-filler.js']
    }).catch(() => {});
  }
});
