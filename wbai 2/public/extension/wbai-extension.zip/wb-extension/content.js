(function() {
  if (window.__wbLoaded) return;
  window.__wbLoaded = true;

  function findByClass(part, root) {
    root = root || document;
    for (const el of root.querySelectorAll('*')) {
      if (el.className && typeof el.className === 'string' && el.className.includes(part))
        return el;
    }
    return null;
  }

  function extractReview() {
    const panel = findByClass('Extended-feedback-item-info-content__card');
    if (!panel) return null;
    const full = panel.innerText || '';
    const comment = full.match(/Комментарий[:\s]+(.+?)(?:\n\n|Выкуп|$)/s);
    if (comment && comment[1].trim().length > 3) return comment[1].trim();
    const plus = full.match(/Плюсы[:\s]+(.+?)(?:\n|Комментарий|Выкуп|$)/);
    if (plus && plus[1].trim().length > 3) return plus[1].trim();
    const lines = full.split('\n').map(l => l.trim()).filter(l =>
      l.length > 5 && /[а-яё]/i.test(l) &&
      !l.match(/^\d{2}\.\d{2}/) &&
      !l.match(/Покупатель|Покупка|Плюсы|Минусы|Выкуп|Ещё|Создать/)
    );
    return lines.length ? lines[lines.length - 1] : null;
  }

  function extractProduct() {
    // Из заголовка панели — название товара вверху
    const card = findByClass('Extended-feedback-item-info-content__card-info-block');
    if (card) {
      const title = findByClass('Extended-feedback-item-info-content__title', card);
      if (title) return title.innerText.trim();
    }
    // Из шапки sidebar
    const sidebar = findByClass('Sidebar-panel__');
    if (sidebar) {
      const h = sidebar.querySelector('h1,h2,h3,[class*="title"],[class*="name"]');
      if (h && h.innerText.trim().length > 5) return h.innerText.trim();
    }
    return 'товар';
  }

  function extractRating() {
    // Ищем рейтинг ТОЛЬКО внутри открытой панели отзыва
    const panel = findByClass('Extended-feedback-item-info-content__card');
    if (!panel) return 5;

    // Оранжевый цвет звёзд WB: rgb(255, 128, 88)
    const svgs = panel.querySelectorAll('[class*="Rating"] svg');
    if (svgs.length > 0) {
      let orange = 0;
      for (const svg of svgs) {
        const color = window.getComputedStyle(svg).color;
        if (color.includes('255, 128') || color.includes('255,128')) orange++;
      }
      if (orange >= 1 && orange <= 5) return orange;
    }

    // Запасной — ищем активный класс внутри панели
    const active = panel.querySelectorAll('[class*="Rating__active"]');
    if (active.length >= 1 && active.length <= 5) return active.length;

    return 5;
  }

  function insertAnswer(text) {
    // Ищем напрямую по id или placeholder
    let el = document.getElementById('answerText');
    if (!el) el = document.querySelector('textarea[placeholder*="ответ"], textarea[placeholder*="Напишите"]');
    if (!el) {
      const areas = document.querySelectorAll('textarea');
      for (const a of areas) { if (a.offsetParent !== null) { el = a; break; } }
    }
    if (!el) return false;

    try {
      // Кликаем и фокусируемся
      el.focus();
      el.click();

      // Очищаем поле через select + delete
      el.setSelectionRange(0, el.value.length);
      document.execCommand('delete', false);

      // Вставляем символ за символом через InputEvent
      // Это самый близкий к реальному вводу способ
      const inputEvent = new InputEvent('input', {
        bubbles: true,
        cancelable: true,
        inputType: 'insertText',
        data: text
      });

      // Устанавливаем значение через дескриптор прототипа
      const desc = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
      if (desc && desc.set) {
        desc.set.call(el, text);
      } else {
        el.value = text;
      }

      el.dispatchEvent(inputEvent);
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      el.dispatchEvent(new Event('focus', { bubbles: true }));

      return el.value === text || el.value.length > 0;
    } catch(e) {
      console.log('insertAnswer error:', e);
      return false;
    }
  }

  function showToast(msg, ok) {
    let t = document.getElementById('wb-ai-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'wb-ai-toast';
      t.style.cssText = 'position:fixed;bottom:90px;right:20px;padding:10px 16px;border-radius:10px;font-size:13px;font-weight:600;z-index:999999;font-family:-apple-system,sans-serif;box-shadow:0 4px 20px rgba(0,0,0,0.3);transition:opacity 0.3s;pointer-events:none;';
      document.body.appendChild(t);
    }
    t.style.background = ok ? '#1a2d1a' : '#2a1a1a';
    t.style.border = ok ? '1px solid #4caf50' : '1px solid #7f3333';
    t.style.color = ok ? '#7ed47e' : '#ff8888';
    t.textContent = msg;
    t.style.opacity = '1';
    clearTimeout(t._tm);
    t._tm = setTimeout(() => t.style.opacity = '0', 3500);
  }

  let isGen = false;

  function createBtn() {
    const btn = document.createElement('button');
    btn.id = 'wb-ai-btn';
    btn.type = 'button';
    btn.innerHTML = `<span style="margin-right:4px">✨</span>AI ответ`;
    btn.style.cssText = `
      display:inline-flex;align-items:center;
      background:linear-gradient(135deg,#7b2ff7,#5a1fc7);
      color:#fff;border:none;border-radius:8px;
      padding:5px 12px;font-size:12px;font-weight:600;
      cursor:pointer;font-family:inherit;
      white-space:nowrap;height:28px;
      transition:opacity 0.15s;
    `;
    btn.onmouseover = () => btn.style.opacity = '.85';
    btn.onmouseout = () => btn.style.opacity = '1';

    btn.addEventListener('click', async e => {
      e.preventDefault(); e.stopPropagation();
      if (isGen) return;
      isGen = true;
      btn.innerHTML = '⚙️ Генерирую...';
      btn.style.opacity = '.7';

      const review = extractReview();
      const product = extractProduct();
      const rating = extractRating();

      if (!review) {
        showToast('❌ Не могу прочитать текст отзыва', false);
        btn.innerHTML = '<span style="margin-right:4px">✨</span>AI ответ';
        btn.style.opacity = '1';
        isGen = false;
        return;
      }

      // Выбор стиля
      const style = await new Promise(function(resolve) {
        const ov = document.createElement('div');
        ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:1000001;display:flex;align-items:center;justify-content:center;';
        const m = document.createElement('div');
        m.style.cssText = 'background:#fff;border-radius:14px;padding:20px;width:320px;font-family:-apple-system,sans-serif;box-shadow:0 10px 40px rgba(0,0,0,0.2);';
        m.innerHTML =
          '<div style="font-size:15px;font-weight:700;color:#1a1a1a;margin-bottom:14px;">Выберите стиль ответа</div>' +
          '<div style="display:flex;flex-direction:column;gap:10px;">' +
          '<button id="wb-style-fun" style="padding:12px;border:2px solid #7b2ff7;border-radius:10px;background:#f5f0ff;color:#7b2ff7;font-size:14px;font-weight:700;cursor:pointer;">😄 С юмором</button>' +
          '<button id="wb-style-official" style="padding:12px;border:2px solid #555;border-radius:10px;background:#f5f5f5;color:#333;font-size:14px;font-weight:700;cursor:pointer;">💼 Официально</button>' +
          '<button id="wb-style-cancel" style="padding:8px;border:none;background:none;color:#aaa;font-size:13px;cursor:pointer;">Отмена</button>' +
          '</div>';
        ov.appendChild(m);
        document.body.appendChild(ov);
        document.getElementById('wb-style-fun').onclick = function() { ov.remove(); resolve('fun'); };
        document.getElementById('wb-style-official').onclick = function() { ov.remove(); resolve('official'); };
        document.getElementById('wb-style-cancel').onclick = function() { ov.remove(); resolve(null); };
      });

      if (!style) {
        btn.innerHTML = '<span style="margin-right:4px">✨</span>AI ответ';
        btn.style.opacity = '1';
        isGen = false;
        return;
      }

      const typeLabel = rating >= 5 ? '5 звёзд — хвалит' : rating <= 2 ? '1-2 звезды — недоволен' : '3-4 звезды — нейтральный';

      const prompt = style === 'fun'
        ? `ЗАДАЧА: Ты — дерзкий мемный SMM магазина на Wildberries. Напиши один лучший ответ на отзыв.

ГЛАВНОЕ: юмор ТОЧНО ПО ТЕМЕ отзыва — цепляйся за конкретные слова из текста отзыва. Шутка должна быть понятна всем.
СТИЛЬ: дерзкий, мемный, уважительный, 2-3 предложения, никаких "Спасибо за ваш отзыв!".
Можно обращаться по имени если оно указано. Максимум 3 смайлика.

ВАЖНОЕ ПРАВИЛО — куда направлять покупателя:
- Проблема с ТОВАРОМ (неполный комплект, брак, не работает) → пиши "напишите нам в чат"
- Проблема с ДОСТАВКОЙ, ВОЗВРАТОМ ДЕНЕГ → пиши "обратитесь в поддержку Wildberries"

ЗАПРЕЩЕНО (ответ отклонят модераторы WB):
- НЕ критикуй покупателя и не обвиняй его ни в чём
- НЕ используй сленг "Чел", "Чувак" и подобное
- НЕ используй заглавные буквы подряд
- НЕ пиши "приходите снова" или "ждём вас"
- НЕ более 2 восклицательных знаков подряд

ТОВАР: ${product}
ТИП: ${typeLabel}
ОТЗЫВ: "${review}"

Напиши только текст ответа без кавычек и пояснений.`
        : `Ты — вежливый представитель магазина на Wildberries. Напиши официальный ответ на отзыв покупателя.

СТИЛЬ: деловой, вежливый, без юмора, 2-3 предложения.
Можно обращаться по имени если оно указано.

ВАЖНОЕ ПРАВИЛО — куда направлять покупателя:
- Проблема с ТОВАРОМ (неполный комплект, брак, не работает, не то прислали) → пиши "обратитесь к нам в чат магазина"
- Проблема с ДОСТАВКОЙ, ВОЗВРАТОМ ДЕНЕГ, ЛОГИСТИКОЙ → пиши "обратитесь в службу поддержки Wildberries"

ПРАВИЛА МОДЕРАЦИИ WB:
- Только информация о товаре
- Без сленга и смайликов
- Без критики покупателя
- Грамотный русский язык
- Без заглавных букв подряд

ТОВАР: ${product}
ТИП: ${typeLabel}
ОТЗЫВ: "${review}"

Напиши только текст ответа без кавычек и пояснений.`;

      chrome.runtime.sendMessage({ action: 'callAI', prompt }, resp => {
        isGen = false;
        btn.innerHTML = '<span style="margin-right:4px">✨</span>AI ответ';
        btn.style.opacity = '1';

        if (!resp || resp.error) {
          showToast('❌ Ошибка AI: ' + (resp?.error?.slice(0,80) || 'нет ответа'), false);
          return;
        }

        const text = resp.text.trim();
        const ok = insertAnswer(text);
        if (ok) {
          showToast('✅ Ответ вставлен! Проверьте и нажмите отправить.', true);
        } else {
          showToast('❌ Не удалось вставить ответ', false);
        }
      });
    });

    return btn;
  }

  function tryInject() {
    if (document.getElementById('wb-ai-btn')) return;
    // Определяем вкладку по уникальным классам
    var isReviewTab = !!document.querySelector('[class*="Not-answered-feedbacks"]');
    var isQuestionTab = !!document.querySelector('[class*="Extended-question-item"]');
    // Кнопка отзывов только на вкладке отзывов
    if (!isReviewTab || isQuestionTab) return;

    // Ищем панель с кнопками "Шаблоны" и "Ещё" — точный класс из скриншота
    const controlPanel = findByClass('Answer-form__control-panel__');
    if (controlPanel) {
      controlPanel.appendChild(createBtn());
      return;
    }

    // Fallback — ищем строку где есть "Шаблоны"
    const allEls = document.querySelectorAll('*');
    for (const el of allEls) {
      if (el.children.length === 0 && el.innerText && el.innerText.trim() === 'Шаблоны') {
        const row = el.closest('[class*="control"]') || el.parentElement?.parentElement;
        if (row && !row.querySelector('#wb-ai-btn')) {
          row.appendChild(createBtn());
          return;
        }
      }
    }

    // Fallback 2 — вставляем перед полем ответа
    const answerForm = findByClass('Answer-form__control-wrapper__');
    if (answerForm && !answerForm.querySelector('#wb-ai-btn')) {
      const wrap = document.createElement('div');
      wrap.style.cssText = 'padding:6px 8px 0;display:flex;';
      wrap.appendChild(createBtn());
      answerForm.insertBefore(wrap, answerForm.firstChild);
    }
  }

  // MutationObserver — следим за открытием панели
  const observer = new MutationObserver(() => {
    const panel = findByClass('Answer-form__');
    if (panel) {
      setTimeout(tryInject, 300);
    } else {
      const btn = document.getElementById('wb-ai-btn');
      if (btn) btn.remove();
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Обработка сообщений от popup
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === 'getReview')
      sendResponse({ review: extractReview(), rating: extractRating(), product: extractProduct() });
    if (req.action === 'insertAnswer')
      sendResponse({ ok: insertAnswer(req.text) });
  });

})();

// ===== ОТВЕТЫ НА ВОПРОСЫ =====
(function() {
  var isGenerating = false;

  function getQuestionData() {
    var sidebar = document.querySelector('[class*="Sidebar"]');
    if (!sidebar) return null;
    var text = (sidebar.innerText || '').trim();
    var lines = text.split('\n').map(function(l) { return l.trim(); }).filter(function(l) { return l.length > 0; });
    
    // Название товара — первая строка
    var productName = lines[0] || '';
    // Вопрос — ищем длинную строку после даты
    var question = '';
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].match(/\d{2}\.\d{2}\.\d{4}/)) {
        question = lines.slice(i + 1).join(' ').trim();
        break;
      }
    }
    return { productName: productName, question: question };
  }

  function getTemplates() {
    try { return JSON.parse(localStorage.getItem('wb_templates') || '{}'); } catch(e) { return {}; }
  }

  function showTemplateSelect(productName, question) {
    return new Promise(function(resolve) {
      var templates = getTemplates();
      var tNames = Object.keys(templates);

      var ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:1000000;display:flex;align-items:center;justify-content:center;';
      var m = document.createElement('div');
      m.style.cssText = 'background:#fff;border-radius:14px;padding:20px;width:420px;font-family:-apple-system,sans-serif;box-shadow:0 10px 40px rgba(0,0,0,0.2);max-height:80vh;overflow-y:auto;';

      var tmplBtns = tNames.length > 0
        ? tNames.map(function(n) {
            return '<button class="wb-q-tmpl" data-n="' + n + '" style="display:block;width:100%;text-align:left;padding:8px 12px;margin-bottom:6px;border:1px solid #e0d4f7;border-radius:8px;background:#f5f0ff;color:#333;font-size:13px;cursor:pointer;">' + n + '</button>';
          }).join('')
        : '<div style="color:#888;font-size:13px;">Нет сохранённых шаблонов. Сначала создайте карточку и сохраните шаблон.</div>';

      m.innerHTML =
        '<div style="font-size:15px;font-weight:700;color:#1a1a1a;margin-bottom:4px;">✨ AI ответ на вопрос</div>' +
        '<div style="font-size:12px;color:#888;margin-bottom:12px;">Товар: <b>' + productName + '</b></div>' +
        '<div style="font-size:12px;color:#555;background:#f5f5f5;border-radius:8px;padding:10px;margin-bottom:14px;font-style:italic;">"' + question.slice(0, 150) + (question.length > 150 ? '...' : '') + '"</div>' +
        '<div style="font-size:12px;font-weight:600;color:#555;margin-bottom:8px;">Выберите шаблон товара:</div>' +
        tmplBtns +
        '<div style="display:flex;gap:8px;margin-top:12px;">' +
        '<button id="wb-q-cancel" style="flex:1;padding:9px;border:1px solid #ddd;border-radius:8px;background:#f5f5f5;color:#555;font-size:13px;cursor:pointer;">Отмена</button>' +
        '<button id="wb-q-nochars" style="flex:1;padding:9px;border:none;border-radius:8px;background:#7b2ff7;color:#fff;font-size:13px;font-weight:600;cursor:pointer;">Без характеристик</button>' +
        '</div>';

      ov.appendChild(m);
      document.body.appendChild(ov);

      m.querySelectorAll('.wb-q-tmpl').forEach(function(btn) {
        btn.onclick = function() {
          var n = btn.getAttribute('data-n');
          var t = getTemplates()[n];
          ov.remove();
          resolve({ chars: t ? t.chars : '', name: n });
        };
      });

      document.getElementById('wb-q-cancel').onclick = function() { ov.remove(); resolve(null); };
      document.getElementById('wb-q-nochars').onclick = function() { ov.remove(); resolve({ chars: '', name: '' }); };
    });
  }

  function insertAnswer(text) {
    var el = document.getElementById('answerText');
    if (!el) return false;
    el.focus();
    el.click();
    var desc = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
    if (desc && desc.set) desc.set.call(el, text);
    else el.value = text;
    el.dispatchEvent(new InputEvent('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function showToast(msg, ok) {
    var t = document.getElementById('wb-q-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'wb-q-toast';
      t.style.cssText = 'position:fixed;bottom:80px;right:20px;padding:10px 16px;border-radius:10px;font-size:13px;font-weight:600;z-index:999999;font-family:-apple-system,sans-serif;box-shadow:0 4px 20px rgba(0,0,0,0.2);transition:opacity 0.3s;';
      document.body.appendChild(t);
    }
    t.style.background = ok ? '#1a2d1a' : '#2a1a1a';
    t.style.border = ok ? '1px solid #4caf50' : '1px solid #c0392b';
    t.style.color = ok ? '#7ed47e' : '#ff8888';
    t.textContent = msg;
    t.style.opacity = '1';
    clearTimeout(t._tm);
    t._tm = setTimeout(function() { t.style.opacity = '0'; }, 4000);
  }

  async function handleQuestion() {
    if (isGenerating) return;
    var data = getQuestionData();
    if (!data || !data.question) { showToast('Не могу прочитать вопрос', false); return; }

    var selected = await showTemplateSelect(data.productName, data.question);
    if (!selected) return;

    isGenerating = true;
    var btn = document.getElementById('wb-q-btn');
    if (btn) { btn.textContent = '⏳'; btn.style.opacity = '0.7'; }
    showToast('Генерирую ответ...', true);

    var charsText = selected.chars ? '\nХАРАКТЕРИСТИКИ ТОВАРА:\n' + selected.chars : '';
    var prompt =
      'Ты менеджер магазина на Wildberries. Ответь на вопрос покупателя.\n\n' +
      'ТОВАР: ' + data.productName + charsText + '\n\n' +
      'ВОПРОС ПОКУПАТЕЛЯ: ' + data.question + '\n\n' +
      'ПРАВИЛА:\n' +
      '- Отвечай вежливо и по существу\n' +
      '- Если вопрос про характеристики — используй данные товара\n' +
      '- Если характеристик нет — отвечай общими словами и предложи уточнить\n' +
      '- 2-4 предложения\n' +
      '- Без "Спасибо за вопрос"\n' +
      '- Обращайся на Вы\n' +
      'Только текст ответа.';

    chrome.runtime.sendMessage({ action: 'callAI', prompt: prompt }, function(resp) {
      isGenerating = false;
      if (btn) { btn.textContent = '✨ AI ответ'; btn.style.opacity = '1'; }
      if (!resp || !resp.text) { showToast('Ошибка AI', false); return; }

      var ok = insertAnswer(resp.text.trim());
      if (ok) {
        showToast('Ответ вставлен! Нажмите отправить', true);
      } else {
        navigator.clipboard.writeText(resp.text.trim()).then(function() {
          showToast('Скопировано! Нажмите Cmd+V', true);
        });
      }
    });
  }

  function injectQuestionBtn() {
    if (document.getElementById('wb-q-btn')) return;
    var panel = document.querySelector('[class*="Answer-form__control-wrapper"]');
    if (!panel) return;

    var btn = document.createElement('button');
    btn.id = 'wb-q-btn';
    btn.type = 'button';
    btn.textContent = '✨ AI ответ';
    btn.style.cssText = 'background:linear-gradient(135deg,#7b2ff7,#5a1fc7);color:#fff;border:none;border-radius:8px;padding:5px 12px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;margin-left:8px;';
    btn.onclick = handleQuestion;
    panel.appendChild(btn);
  }

  var qObs = new MutationObserver(function() {
    var panel = document.querySelector('[class*="Answer-form__control-wrapper"]');
    var answerField = document.getElementById('answerText');
    var isQuestionTab = !!document.querySelector('[class*="Extended-question-item"]');
    var isReviewTab = !!document.querySelector('[class*="Not-answered-feedbacks"]');
    // Кнопка вопросов только на вкладке вопросов
    if (panel && isQuestionTab && !isReviewTab) setTimeout(injectQuestionBtn, 300);
    else { var b = document.getElementById('wb-q-btn'); if (b) b.remove(); }
  });
  qObs.observe(document.body, { childList: true, subtree: true });
})();
